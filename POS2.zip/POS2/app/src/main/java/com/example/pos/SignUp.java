package com.example.pos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SignUp extends AppCompatActivity {
    Button sgnbtn;
    TextView auser;
    EditText Name,email,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        sgnbtn=(Button)findViewById(R.id.signup_button);
        auser=(TextView) findViewById(R.id.signup_login);
        Name =(EditText)findViewById(R.id.signup_name);
        email=(EditText)findViewById(R.id.signup_email);
        password =(EditText)findViewById(R.id.signup_password);

        sgnbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (TextUtils.isEmpty(Name.getText().toString()) && TextUtils.isEmpty(email.getText().toString()) && TextUtils.isEmpty((password.getText().toString()))){

                    Toast.makeText(SignUp.this, "Empty field not allowed!", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent sgintent = new Intent(SignUp.this, MainActivity.class);
                    startActivity(sgintent);
                }

            }
        });
        auser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent aintent = new Intent(SignUp.this,MainActivity.class);
                startActivity(aintent);

            }
        });
    }

}