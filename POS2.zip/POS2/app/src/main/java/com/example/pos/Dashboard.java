package com.example.pos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class Dashboard extends AppCompatActivity {

    CardView Products,Customers,Reports,Bills,Setting,Logout;
   // Intent pintent,cintent,rintent,bintent,sintent,lintent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        Products=(CardView)findViewById(R.id.ic_product);
        Customers=(CardView)findViewById(R.id.ic_customer);
        Reports=(CardView)findViewById(R.id.ic_report);
        Bills=(CardView)findViewById(R.id.ic_bill);
        Setting =(CardView)findViewById(R.id.ic_setting);
        Reports=(CardView)findViewById(R.id.ic_report);
       Logout=(CardView)findViewById(R.id.ic_logout);


       Products.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

            Intent pintent = new Intent(Dashboard.this,products.class);
             startActivity(pintent);
           }
       });
        Customers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent cintent = new Intent(Dashboard.this,customers.class);
                startActivity(cintent);
            }
        });
        Reports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent rintent = new Intent(Dashboard.this,Reports.class);
                startActivity(rintent);
            }
        });
        Bills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent bintent = new Intent(Dashboard.this,Bills.class);
                startActivity(bintent);
            }
        });
        Setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent sintent = new Intent(Dashboard.this,Setting.class);
                startActivity(sintent);
            }
        });
        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Dashboard.this);
                builder.setMessage("Do you want to Logout ?");
                builder.setTitle("Alert !");
                builder.setCancelable(false);
                builder.setPositiveButton("Yes", (DialogInterface.OnClickListener) (dialog, which) -> {
                    // When the user click yes button then app will close
                    Intent lintent = new Intent(Dashboard.this,MainActivity.class);
                    startActivity(lintent);
                    finish();
                });

                builder.setNegativeButton("No", (DialogInterface.OnClickListener) (dialog, which) -> {
                    // If user click no then dialog box is canceled.
                    dialog.cancel();
                });

                AlertDialog alertDialog = builder.create();

                alertDialog.show();

            }
        });



    }
    @Override
    public void onBackPressed(){
        new AlertDialog.Builder(this).setMessage("Are you sure you want to exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("No",null).show();

    }
}