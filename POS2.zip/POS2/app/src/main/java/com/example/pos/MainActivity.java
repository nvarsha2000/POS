package com.example.pos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button lgnbtn;
    TextView Signup,ForgetPassword;
    EditText Email,Password ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lgnbtn=(Button)findViewById(R.id.login_button);
        Signup=(TextView)findViewById(R.id.signup_password);
        ForgetPassword=(TextView)findViewById(R.id.forgot_password);
        Email =(EditText)findViewById(R.id.login_email);
        Password =(EditText)findViewById(R.id.login_password);



        lgnbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (TextUtils.isEmpty(Email.getText().toString()) && TextUtils.isEmpty((Password.getText().toString()))){

                    Toast.makeText(MainActivity.this, "Empty field not allowed!", Toast.LENGTH_SHORT).show();
                }
             else if (Email.equals("user") && Password.equals("1234")) {

                 Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_LONG).show();

             }
             else {
                    Intent lintent = new Intent(MainActivity.this,Dashboard.class);
                    startActivity(lintent);
                }

            }
        });
        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent sintent = new Intent(MainActivity.this,SignUp.class);
                startActivity(sintent);

            }
        });        ForgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fintent = new Intent(MainActivity.this,ForgetPassword.class);
                startActivity(fintent);

            }
        });
    }


}